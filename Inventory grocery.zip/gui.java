import javax.swing.*;
import java.awt.*;
import java.util.List;


public class gui {
    private JFrame frame;
    private JTextArea display;

    public gui() {
    frame = new JFrame("E-Commerce Product Management");
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    frame.setBackground(Color.LIGHT_GRAY);
    frame.setBounds(700,350,700, 500);
    JPanel panel = new JPanel();
    
    panel.setBackground(Color.LIGHT_GRAY);
    JButton add = new JButton("Add new product");
    JButton view = new JButton("View all products");
    JButton update = new JButton("Update a roduct");
    JButton delete = new JButton("Delete a Product");
    JButton exit = new JButton("Exit");
    display = new JTextArea();
    display.setEditable(false);
    panel.add(add);
    panel.add(view);
    panel.add(update);
    panel.add(delete);
    panel.add(exit);
    panel.setLayout(new GridLayout(5, 1));
    frame.add(panel, BorderLayout.NORTH);
    frame.add(new JScrollPane(display), BorderLayout.CENTER);
    add.addActionListener(e->add());
    view.addActionListener(e->view());
    update.addActionListener(e->update());
    delete.addActionListener(e->delete());
    exit.addActionListener(e->exit());
    frame.setVisible(true);
    }

     void add() {
try {
        String id = JOptionPane.showInputDialog("Enter Product ID:");
        String name = JOptionPane.showInputDialog("Enter Name:");
        String category = JOptionPane.showInputDialog("Enter Category:");
        double price = Double.parseDouble(JOptionPane.showInputDialog("Enter Price:"));
        int quantity = Integer.parseInt(JOptionPane.showInputDialog("Enter Stock:"));
        product p = new product(id, name, category, price, quantity);
        productmanager.add(p);
        JOptionPane.showMessageDialog(frame, "Product Added!");
} catch (Exception e) {
        JOptionPane.showMessageDialog(frame, "Invalid Input: " + e.getMessage());
        }
    }

     void view() {
        try {
            List<product> list = productmanager.getAllProducts();
            
            for (product p : list) {
                display.append(p.toString() + "\n");}
        } catch (Exception e) {
            JOptionPane.showMessageDialog(frame, "Error");
        }}

    void update() {
        try {
            String id = JOptionPane.showInputDialog("Enter Product ID to update:");
            String name = JOptionPane.showInputDialog("Enter New Name:");
            String category = JOptionPane.showInputDialog("Enter New Category:");
            double price = Double.parseDouble(JOptionPane.showInputDialog("Enter New Price:"));
            int stock = Integer.parseInt(JOptionPane.showInputDialog("Enter New Stock:"));

            product updated = new product(id, name, category, price, stock);
            productmanager.update(updated);
            JOptionPane.showMessageDialog(frame, "Product Updated!");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(frame, "Error: " + e.getMessage());
        }
    }

  void delete() {
        try {
            String id = JOptionPane.showInputDialog("Enter Product ID to delete:");
            productmanager.delete(id);
            JOptionPane.showMessageDialog(frame, "Product Deleted!");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(frame, "Error: " + e.getMessage());
        }
    }

    void exit(){
        System.exit(0);
    }

    public static void main(String[] args) {
        new gui();
    }
}

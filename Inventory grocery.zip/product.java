public class product {
    private String productId;
    private String name;
    private String category;
    private double price;
    private int quantity;

    product(String productId, String name, String category, double price, int quantity){
        this.productId=productId;
        this.name=name;
        this.category=category;
        setprice(price);
        setquantity(quantity);
    

    }

    public String getproductId(){
        return productId;
    }

    public void setproductid(String productId){
        this.productId=productId;
    }

    public String getname(){
        return name;
    }

    public void setname(String name){
        this.name=name;
    }
    public String getcategory(){
        return category;
    }

    public void setcategory(String category){
        this.category=category;
    }


    public double getprice(){
        return price;
    }

    public void setprice(double price){
        if(price>0)
        {this.price=price;}
        else
           throw new IllegalArgumentException("invalid input");
    }
    public int getquantity(){
        return quantity;
    }

    public void setquantity(int quantity){
        if(quantity>=0)
        {this.quantity=quantity;}
        else
           throw new IllegalArgumentException("invalid input");
    }

    
 public String toString() {
        return "ID:" + productId + "," + "Name:" + name + "," + "Category" + category + "," + "Price" + price + "," + "Stock" + quantity;
    }
    public static product fromString(String line) {
        String[] parts = line.split(",");
        return new product(parts[0],parts[1],parts[2],Double.parseDouble(parts[3]),Integer.parseInt(parts[4]));
    }

}









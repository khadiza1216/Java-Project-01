import java.io.*;
import java.util.*;

public class productmanager {
    private static final String filename = "C:\\Users\\HP\\Desktop\\Inventory management system\\product.txt";
//add
    public static void add(product product) throws IOException {
    BufferedWriter writer = new BufferedWriter(new FileWriter(filename, true));
    writer.write(product.toString());
    writer.newLine();
    writer.close();
    }
//display
    public static List<product> getAllProducts() throws IOException {
        List<product> list = new ArrayList<>();
        File file = new File(filename);
        if(!file.exists()) 
           return list;
        BufferedReader reader = new BufferedReader(new FileReader(file));
           String line;
        while ((line = reader.readLine()) != null) {
            list.add(product.fromString(line));
        }
        reader.close();
        return list;
    }
//update
    public static void update(product updatedProduct) throws IOException {
    List<product> products = getAllProducts();
        BufferedWriter writer = new BufferedWriter(new FileWriter(filename));
    for (product p : products) {
     if (p.getproductId().equals(updatedProduct.getproductId())) {
                writer.write(updatedProduct.toString());
            } else {
                writer.write(p.toString());
            }
            
        }
        writer.newLine();
        writer.close();
    }
//delete
    public static void delete(String productId) throws IOException {
    List<product> products = getAllProducts();
    BufferedWriter writer = new BufferedWriter(new FileWriter(filename));
        for (product p : products) {
    if (!p.getproductId().equals(productId)) {
        writer.write(p.toString());
            writer.newLine();
            }
        }
        writer.close();
    }
}
